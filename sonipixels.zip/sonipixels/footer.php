<div class="container-fluid col-sm-12" style="background-color: #444;">
    <div class="main-footer">
      <div class="col-md-3">
        <div class="footer-item">
          <h2>ABOUT</h2>
          <ul>
            <li><a href="#">The Company</a></li>
              <li><a href="#">History</a></li>
              <li><a href="#">Vision</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3">
        <div class="footer-item">
          <h2>CONTACT</h2>
          <ul>
            <li><a href="#">Basic Info</a></li>
            <li><a href="#">Map</a></li>
            <li><a href="#">Contact Form</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3">
        <div class="footer-item">
          <h2>TUTORIALS</h2>
          <ul>
            <li><a href="#">HTML</a></li>
            <li><a href="#">CSS</a></li>
            <li><a href="#">Bootstrap</a></li>
            <li><a href="#">Javascript</a></li>
            <li><a href="#">PHP</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3">
        <div class="footer-item">
          <h2>GALLERY</h2>
          <ul>
              <li><a href="#">lickr</a></li>
              <li><a href="#">Picasa</a></li>
              <li><a href="#">iStockPhoto</a></li>
              <li><a href="#">PhotoDune</a></li>
          </ul>
        </div>
      </div>

      <div class="socio-copyright">
        <div class="social">
          <a target="_blank" href="http://www.facebook.com/sonisoftcorporation"><i class="fa fa-facebook"></i></a>
          <a target="_blank" href="http://www.twitter.com/sonisoftcorporation"><i class="fa fa-twitter"></i></a>
          <a target="_blank" href="http://www.princesonisoft@gmail.com"><i class="fa fa-google-plus"></i></a>
          <a target="_blank" href="http://www.youtube.com/sonisoftcorporation"><i class="fa fa-youtube"></i></a>
        </div>
        <p>copyrights &copy;<a target="_blank" href="http://sonisoftcorporation.com"> Sonisoft Corporation</a>  2018. All rights reserved.
        </p>
      </div>
    </div>
  </div>
  <div class="scrollup">
    <i class="fa fa-angle-double-up"></i>
  </div>